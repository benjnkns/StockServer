Automate the trading by creating own conditions 


### Execution steps

1. Update the rules in conditions
2. Execute parsing_conditions.py
3. Schedule parsing_conditions.py using airflow


<!-- ### Preview

![Network chart](/final_ark_trades.gif) -->


### Medium Article

[Automate the trading](https://towardsdatascience.com/network-graph-of-etf-ark-funds-4f9242f19702)

### Newsletter Subscribe

[Code Sprout newsletter subscribe](https://codesprout.substack.com/welcome)